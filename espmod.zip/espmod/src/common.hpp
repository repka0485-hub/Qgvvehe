#pragma once
#include <android/log.h>
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "EspMod", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "EspMod", __VA_ARGS__)

// Runtime config. Written by the render thread (menu), read by the main thread (gather).
struct Config {
    std::atomic<bool>  masterEnable{true};
    std::atomic<bool>  box{true};
    std::atomic<bool>  name{true};
    std::atomic<bool>  health{true};
    std::atomic<bool>  distance{true};
    std::atomic<bool>  showTeam{false};
    std::atomic<float> maxDistance{250.0f};
    // Assumption: standing player height. Not validated against PlayerHull / CharacterController.
    std::atomic<float> headOffset{1.8f};
};
extern Config g_cfg;

// Screen-space point: Unity convention, origin bottom-left, pixels of Screen.width/height.
struct EspEntry {
    float footX, footY, headX, headY;
    float dist;
    int   health;
    bool  teammate;
    char  name[32];
};

struct TouchState {
    bool  valid = false;
    bool  down  = false;
    float x = 0, y = 0;   // Unity convention (origin bottom-left)
};

struct Snapshot {
    int screenW = 0, screenH = 0;
    uint64_t frame = 0;
    TouchState touch;
    std::vector<EspEntry> entries;
    char status[128] = {0};
};

// game.cpp
bool game_resolve();
bool game_install_hook();
void snapshot_copy(Snapshot& out);

// overlay.cpp
bool overlay_install();
uint64_t overlay_swap_count();
