#pragma once
#include <dlfcn.h>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include "common.hpp"

struct Il2CppDomain; struct Il2CppAssembly; struct Il2CppImage; struct Il2CppClass;
struct Il2CppType; struct Il2CppThread; struct FieldInfo; struct Il2CppString;
struct Il2CppObject { void* klass; void* monitor; };
struct MethodInfo { void* methodPointer; };   // only the first member is relied upon
struct Il2CppArray : Il2CppObject { void* bounds; uintptr_t max_length; };
static constexpr size_t kArrayData = 0x20;    // arm64: header 16 + bounds 8 + length 8

namespace il2cpp {

struct Api {
    Il2CppDomain*          (*domain_get)();
    const Il2CppAssembly** (*domain_get_assemblies)(const Il2CppDomain*, size_t*);
    const Il2CppImage*     (*assembly_get_image)(const Il2CppAssembly*);
    const char*            (*image_get_name)(const Il2CppImage*);
    Il2CppClass*           (*class_from_name)(const Il2CppImage*, const char*, const char*);
    const MethodInfo*      (*class_get_method_from_name)(Il2CppClass*, const char*, int);
    FieldInfo*             (*class_get_field_from_name)(Il2CppClass*, const char*);
    const Il2CppType*      (*class_get_type)(Il2CppClass*);
    Il2CppObject*          (*type_get_object)(const Il2CppType*);
    Il2CppObject*          (*runtime_invoke)(const MethodInfo*, void*, void**, Il2CppObject**);
    void*                  (*object_unbox)(Il2CppObject*);
    void                   (*field_get_value)(Il2CppObject*, FieldInfo*, void*);
    const uint16_t*        (*string_chars)(Il2CppString*);
    int                    (*string_length)(Il2CppString*);
    Il2CppString*          (*string_new)(const char*);
    uint32_t               (*gchandle_new)(Il2CppObject*, bool);
    Il2CppThread*          (*thread_attach)(Il2CppDomain*);
};
inline Api A{};

inline bool bind() {
    void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) return false;
    bool ok = true;
#define B(n) do { A.n = (decltype(A.n))dlsym(h, "il2cpp_" #n); \
                  if (!A.n) { LOGE("missing export il2cpp_%s", #n); ok = false; } } while (0)
    B(domain_get); B(domain_get_assemblies); B(assembly_get_image); B(image_get_name);
    B(class_from_name); B(class_get_method_from_name); B(class_get_field_from_name);
    B(class_get_type); B(type_get_object); B(runtime_invoke); B(object_unbox);
    B(field_get_value); B(string_chars); B(string_length); B(string_new);
    B(gchandle_new); B(thread_attach);
#undef B
    return ok;
}

// Searches every loaded image; namespace is exact ("" for the global namespace).
inline Il2CppClass* find_class(const char* ns, const char* name) {
    size_t n = 0;
    const Il2CppAssembly** asms = A.domain_get_assemblies(A.domain_get(), &n);
    for (size_t i = 0; i < n; ++i) {
        const Il2CppImage* img = A.assembly_get_image(asms[i]);
        if (!img) continue;
        if (Il2CppClass* c = A.class_from_name(img, ns, name)) return c;
    }
    return nullptr;
}

inline const MethodInfo* find_method(Il2CppClass* c, const char* name, int argc) {
    return c ? A.class_get_method_from_name(c, name, argc) : nullptr;
}

// Returns nullptr on managed exception or null result.
inline Il2CppObject* call(const MethodInfo* m, void* self, void** args = nullptr) {
    Il2CppObject* exc = nullptr;
    Il2CppObject* r = A.runtime_invoke(m, self, args, &exc);
    return exc ? nullptr : r;
}

template <class T> inline bool unbox(Il2CppObject* o, T& out) {
    if (!o) return false;
    out = *static_cast<T*>(A.object_unbox(o));
    return true;
}

inline void to_ascii(Il2CppString* s, char* out, size_t cap) {
    size_t k = 0;
    if (s) {
        const uint16_t* c = A.string_chars(s);
        int n = A.string_length(s);
        for (int i = 0; i < n && k + 1 < cap; ++i) out[k++] = c[i] < 0x80 ? (char)c[i] : '?';
    }
    out[k] = 0;
}

} // namespace il2cpp
