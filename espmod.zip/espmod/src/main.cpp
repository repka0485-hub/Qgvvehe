#include "common.hpp"
#include "il2cpp.hpp"
#include <chrono>
#include <thread>

static void bootstrap() {
    using namespace std::chrono_literals;

    // 1. libil2cpp.so loaded and exporting the il2cpp API
    for (int i = 0; i < 240 && !il2cpp::bind(); ++i) std::this_thread::sleep_for(500ms);
    if (!il2cpp::A.domain_get) { LOGE("libil2cpp.so / il2cpp exports unavailable; aborting"); return; }

    // 2. game assemblies registered (PlayerController resolvable)
    bool resolved = false;
    for (int i = 0; i < 240 && !resolved; ++i) {
        if (il2cpp::A.domain_get() && il2cpp::A.domain_get_assemblies) resolved = game_resolve();
        if (!resolved) std::this_thread::sleep_for(500ms);
    }
    if (!resolved) { LOGE("game_resolve never succeeded; no hooks installed"); return; }

    // 3. hooks (only reached when every handle resolved)
    if (!game_install_hook()) return;
    if (!overlay_install()) return;

    // 4. watchdog: GLES path produces no frames -> renderer is probably not GLES
    std::this_thread::sleep_for(15s);
    if (overlay_swap_count() == 0)
        LOGE("eglSwapBuffers never called in 15 s: renderer is likely Vulkan; overlay will not draw");
    else
        LOGI("eglSwapBuffers calls so far: %llu", (unsigned long long)overlay_swap_count());
}

__attribute__((constructor)) static void on_load() {
    std::thread(bootstrap).detach();
}
